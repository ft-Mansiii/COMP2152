# Sample Coding Questions 01 Week 01
# Mansi .
arr = [1, 4, 7, 9]
a=1
b=2
c=3
d=4
e = a - ((b ** c) // d) + (a % c)
temperature = 32.6
print("The temperature today is: {:.3f} degrees Celsius".format(temperature))
userAge = int(input("What is your age?")) + 22
print(f"Now showing the shop items filtered by age: {userAge}")